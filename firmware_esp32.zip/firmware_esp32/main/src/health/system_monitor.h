#pragma once
void logSystem();
